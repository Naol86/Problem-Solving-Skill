import random

print(random.randint(3, 9))